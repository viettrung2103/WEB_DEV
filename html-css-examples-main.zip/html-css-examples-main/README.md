# html-css-examples
1. Click on the green 'Code' button, choose `Download ZIP`
2. Extract the ZIP and move the contents to a folder of your choice.
